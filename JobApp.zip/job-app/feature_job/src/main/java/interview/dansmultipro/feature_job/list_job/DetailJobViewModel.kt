package interview.dansmultipro.feature_job.list_job

import androidx.lifecycle.ViewModel

class DetailJobViewModel : ViewModel() {
}