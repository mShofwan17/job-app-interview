package interview.dansmultipro.feature_account.account

import androidx.lifecycle.ViewModel

class AccountViewModel : ViewModel() {
}