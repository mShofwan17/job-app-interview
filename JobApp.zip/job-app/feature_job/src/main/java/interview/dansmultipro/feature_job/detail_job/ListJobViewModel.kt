package interview.dansmultipro.feature_job.detail_job

import androidx.lifecycle.ViewModel

class ListJobViewModel : ViewModel() {
}