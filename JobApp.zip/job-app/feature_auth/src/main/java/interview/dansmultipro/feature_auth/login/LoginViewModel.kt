package interview.dansmultipro.feature_auth.login

import androidx.lifecycle.ViewModel

class LoginViewModel : ViewModel() {
}